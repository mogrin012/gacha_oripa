import { Clock } from "lucide-react"

interface RemainingProgressProps {
  remaining: number
  total: number
}

export function RemainingProgress({ remaining, total }: RemainingProgressProps) {
  const percentage = (remaining / total) * 100

  return (
    <div className="mx-auto mb-6 max-w-md">
      <div className="rounded-xl border border-border/50 bg-card/50 p-4">
        <div className="mb-2 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4 text-gold" />
            <span className="text-sm font-medium text-foreground">残り口数</span>
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-xl font-bold text-gold">{remaining}</span>
            <span className="text-sm text-muted-foreground">/ {total}</span>
          </div>
        </div>

        <div className="relative h-3 overflow-hidden rounded-full bg-secondary">
          <div
            className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-gold-dark via-gold to-gold-light transition-all duration-500"
            style={{ width: `${percentage}%` }}
          />
          <div className="animate-shimmer absolute inset-0 rounded-full" />
        </div>

        <p className="mt-2 text-center text-xs text-muted-foreground">※ 完売次第終了となります</p>
      </div>
    </div>
  )
}
