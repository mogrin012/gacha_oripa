import Link from "next/link"
import { Plus } from "lucide-react"

export function Footer() {
  return (
    <footer className="border-t border-border/50 bg-secondary/30">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col items-center gap-6">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-gold-light to-gold">
              <Plus className="h-5 w-5 text-primary-foreground" strokeWidth={3} />
            </div>
            <span className="bg-gradient-to-r from-gold-light to-amber bg-clip-text text-lg font-bold text-transparent">
              プラスオリパ
            </span>
          </Link>

          {/* Links */}
          <nav className="flex flex-wrap justify-center gap-4 text-sm">
            <Link href="/about" className="text-muted-foreground hover:text-gold transition-colors">
              プラスオリパについて
            </Link>
            <Link href="/terms" className="text-muted-foreground hover:text-gold transition-colors">
              利用規約
            </Link>
            <Link href="/privacy" className="text-muted-foreground hover:text-gold transition-colors">
              プライバシーポリシー
            </Link>
            <Link href="/legal" className="text-muted-foreground hover:text-gold transition-colors">
              特定商取引法に基づく表記
            </Link>
            <Link href="/admin" className="text-muted-foreground hover:text-gold transition-colors">
              管理用
            </Link>
          </nav>

          {/* Copyright */}
          <p className="text-xs text-muted-foreground">© 2025 プラスオリパ All Rights Reserved.</p>
        </div>
      </div>
    </footer>
  )
}
