import { Crown, Star, Award } from "lucide-react"

const prizeData = {
  s: [
    { name: "リザードン SAR", rarity: "SAR", image: "Charizard SAR Pokemon card shiny holographic" },
    { name: "ピカチュウ SAR", rarity: "SAR", image: "Pikachu SAR Pokemon card special art rare" },
  ],
  a: [
    { name: "ミュウツー SR", rarity: "SR", image: "Mewtwo SR Pokemon card super rare" },
    { name: "レックウザ SR", rarity: "SR", image: "Rayquaza SR Pokemon card holographic" },
    { name: "ゲンガー SR", rarity: "SR", image: "Gengar SR Pokemon card super rare" },
    { name: "ルカリオ SR", rarity: "SR", image: "Lucario SR Pokemon card shiny" },
  ],
}

export function PrizeCards() {
  return (
    <section className="mx-auto max-w-2xl">
      <div className="mb-6 text-center">
        <h2 className="bg-gradient-to-r from-gold-light to-gold bg-clip-text text-xl font-bold text-transparent">
          目玉カード一覧
        </h2>
        <p className="mt-1 text-sm text-muted-foreground">このオリパで排出されるレアカード</p>
      </div>

      {/* S Rank prizes */}
      <div className="mb-6">
        <div className="mb-3 flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-gold-light to-gold">
            <Crown className="h-4 w-4 text-primary-foreground" />
          </div>
          <span className="text-lg font-bold text-gold">S賞</span>
          <span className="rounded-full bg-gold/20 px-2 py-0.5 text-xs text-gold">超激レア</span>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {prizeData.s.map((card, index) => (
            <div
              key={index}
              className="group relative overflow-hidden rounded-xl border-2 border-gold/50 bg-gradient-to-br from-gold/10 via-card to-gold/5 p-3 transition-all hover:border-gold hover:shadow-lg hover:shadow-gold/20"
            >
              <div className="relative mb-2 aspect-[3/4] overflow-hidden rounded-lg">
                <img
                  src={`/.jpg?height=200&width=150&query=${card.image}`}
                  alt={card.name}
                  className="h-full w-full object-cover transition-transform group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/60 to-transparent" />
                <div className="absolute bottom-2 left-2 rounded-md bg-gold px-2 py-0.5">
                  <span className="text-xs font-bold text-primary-foreground">{card.rarity}</span>
                </div>
              </div>
              <p className="truncate text-center text-sm font-bold text-foreground">{card.name}</p>
            </div>
          ))}
        </div>
      </div>

      {/* A Rank prizes */}
      <div>
        <div className="mb-3 flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-amber/80 to-amber">
            <Star className="h-4 w-4 text-primary-foreground" />
          </div>
          <span className="text-lg font-bold text-amber">A賞</span>
          <span className="rounded-full bg-amber/20 px-2 py-0.5 text-xs text-amber">激レア</span>
        </div>

        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          {prizeData.a.map((card, index) => (
            <div
              key={index}
              className="group relative overflow-hidden rounded-xl border border-amber/30 bg-gradient-to-br from-amber/5 via-card to-amber/5 p-2 transition-all hover:border-amber/60 hover:shadow-md hover:shadow-amber/10"
            >
              <div className="relative mb-2 aspect-[3/4] overflow-hidden rounded-lg">
                <img
                  src={`/.jpg?height=160&width=120&query=${card.image}`}
                  alt={card.name}
                  className="h-full w-full object-cover transition-transform group-hover:scale-105"
                />
                <div className="absolute bottom-1 left-1 rounded bg-amber/90 px-1.5 py-0.5">
                  <span className="text-[10px] font-bold text-primary-foreground">{card.rarity}</span>
                </div>
              </div>
              <p className="truncate text-center text-xs font-medium text-foreground">{card.name}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Footer note */}
      <div className="mt-8 rounded-lg border border-border/50 bg-card/30 p-4">
        <div className="flex items-start gap-2">
          <Award className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
          <div className="text-xs text-muted-foreground">
            <p className="mb-1 font-medium">注意事項</p>
            <ul className="space-y-1">
              <li>・ 表示されているカードは一例です</li>
              <li>・ 当選確率は公式サイトをご確認ください</li>
              <li>・ 画像はイメージです。実際の商品と異なる場合があります</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}
