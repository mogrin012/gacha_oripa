import { Coins, Plus } from "lucide-react"
import Link from "next/link"

interface HeaderProps {
  points: number
}

export function Header({ points }: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 border-b border-border/50 bg-background/80 backdrop-blur-xl">
      <div className="container mx-auto flex h-14 items-center justify-between px-4">
        <Link href="/" className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-gold-light to-gold">
            <Plus className="h-5 w-5 text-primary-foreground" strokeWidth={3} />
          </div>
          <span className="bg-gradient-to-r from-gold-light to-amber bg-clip-text text-lg font-bold text-transparent">
            プラスオリパ
          </span>
        </Link>

        <div className="flex items-center gap-2 rounded-full border border-gold/30 bg-secondary/50 px-4 py-2">
          <Coins className="h-4 w-4 text-gold" />
          <span className="text-sm font-bold text-gold">{points.toLocaleString()}</span>
          <span className="text-xs text-muted-foreground">pt</span>
        </div>
      </div>
    </header>
  )
}
