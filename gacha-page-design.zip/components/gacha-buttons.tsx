"use client"
import { Zap } from "lucide-react"

interface GachaButtonsProps {
  points: number
  remaining: number
  onPull: (cost: number, pulls: number) => void
}

export function GachaButtons({ points, remaining, onPull }: GachaButtonsProps) {
  const singleCost = 500
  const tenCost = 5000
  const hundredCost = 50000

  const canPullSingle = points >= singleCost && remaining >= 1
  const canPullTen = points >= tenCost && remaining >= 10
  const canPullHundred = points >= hundredCost && remaining >= 100

  return (
    <div className="mx-auto mb-8 max-w-md space-y-3">
      {/* Single pull button */}
      <button
        onClick={() => onPull(singleCost, 1)}
        disabled={!canPullSingle}
        className="group relative w-full overflow-hidden rounded-xl border-2 border-gold/50 bg-gradient-to-r from-secondary via-card to-secondary p-4 transition-all hover:border-gold hover:shadow-lg hover:shadow-gold/20 disabled:cursor-not-allowed disabled:opacity-50"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gold/20">
              <Zap className="h-5 w-5 text-gold" />
            </div>
            <div className="text-left">
              <p className="text-lg font-bold text-foreground">1回引く</p>
            </div>
          </div>
          <div className="text-right">
            <p className="bg-gradient-to-r from-gold-light to-gold bg-clip-text text-2xl font-black text-transparent">
              500
            </p>
            <p className="text-xs text-muted-foreground">pt</p>
          </div>
        </div>
        <div className="absolute inset-0 opacity-0 transition-opacity group-hover:opacity-100">
          <div className="animate-shimmer h-full w-full bg-gradient-to-r from-transparent via-gold/10 to-transparent" />
        </div>
      </button>

      {/* 10-pull button */}
      <button
        onClick={() => onPull(tenCost, 10)}
        disabled={!canPullTen}
        className="group relative w-full overflow-hidden rounded-xl border-2 border-gold bg-gradient-to-r from-gold-dark via-gold to-gold-dark p-4 shadow-lg shadow-gold/30 transition-all hover:shadow-xl hover:shadow-gold/40 disabled:cursor-not-allowed disabled:opacity-50"
      >
        <div className="absolute -right-4 -top-4 h-16 w-16 rounded-full bg-gold-light/30 blur-xl" />
        <div className="absolute -bottom-4 -left-4 h-16 w-16 rounded-full bg-amber/30 blur-xl" />

        <div className="relative flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary-foreground/20">
              <div className="flex">
                <Zap className="h-5 w-5 text-primary-foreground" />
                <span className="text-xs font-bold text-primary-foreground">×10</span>
              </div>
            </div>
            <div className="text-left">
              <p className="text-xl font-bold text-primary-foreground">10連ガチャ</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-3xl font-black text-primary-foreground">5,000</p>
            <p className="text-xs text-primary-foreground/70">pt</p>
          </div>
        </div>
      </button>

      {/* 100-pull button */}
      <button
        onClick={() => onPull(hundredCost, 100)}
        disabled={!canPullHundred}
        className="group relative w-full overflow-hidden rounded-xl border-2 border-amber bg-gradient-to-r from-amber via-gold-light to-amber p-4 shadow-lg shadow-amber/30 transition-all hover:shadow-xl hover:shadow-amber/40 disabled:cursor-not-allowed disabled:opacity-50"
      >
        <div className="absolute -right-6 -top-6 h-20 w-20 rounded-full bg-white/20 blur-xl" />
        <div className="absolute -bottom-6 -left-6 h-20 w-20 rounded-full bg-gold/30 blur-xl" />

        <div className="relative flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-14 w-14 items-center justify-center rounded-lg bg-primary-foreground/20">
              <div className="flex flex-col items-center">
                <Zap className="h-6 w-6 text-primary-foreground" />
                <span className="text-xs font-bold text-primary-foreground">×100</span>
              </div>
            </div>
            <div className="text-left">
              <p className="text-xl font-bold text-primary-foreground">100連ガチャ</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-3xl font-black text-primary-foreground">50,000</p>
            <p className="text-xs text-primary-foreground/70">pt</p>
          </div>
        </div>
      </button>
    </div>
  )
}
