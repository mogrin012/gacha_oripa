import { Sparkles } from "lucide-react"

export function HeroBanner() {
  return (
    <div className="relative mt-4 overflow-hidden rounded-2xl border border-gold/20 bg-gradient-to-br from-secondary via-background to-secondary p-6">
      {/* Decorative elements */}
      <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-gold/10 blur-3xl" />
      <div className="absolute -bottom-10 -left-10 h-40 w-40 rounded-full bg-amber/10 blur-3xl" />

      <div className="relative z-10 flex flex-col items-center text-center">
        <div className="mb-3 flex items-center gap-2 rounded-full border border-gold/30 bg-gold/10 px-4 py-1.5">
          <Sparkles className="h-4 w-4 text-gold" />
          <span className="text-sm font-medium text-gold">期間限定</span>
        </div>

        <h1 className="mb-2 bg-gradient-to-r from-gold-light via-amber to-gold bg-clip-text text-2xl font-bold text-transparent">
          超激アツ祭 開催中！
        </h1>

        <p className="text-sm text-muted-foreground">今だけ限定オリパが登場！最大100倍の超高額カードをGET！</p>
      </div>
    </div>
  )
}
