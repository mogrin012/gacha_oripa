import { GachaCard } from "@/components/gacha-card"

const gachaList = [
  {
    id: "1",
    title: "超激レアBOX",
    subtitle: "ポケカSAR確定",
    price: 500,
    remaining: 120,
    total: 1000,
    image: "/pokemon-rare-trading-card-sar-shiny.jpg",
    badge: "激アツ",
    badgeColor: "red" as const,
  },
  {
    id: "2",
    title: "リザードンBOX",
    subtitle: "リザードン系確定",
    price: 1000,
    remaining: 45,
    total: 500,
    image: "/charizard-pokemon-card-holographic-fire.jpg",
    badge: "人気",
    badgeColor: "gold" as const,
  },
  {
    id: "3",
    title: "初心者応援BOX",
    subtitle: "SR以上1枚確定",
    price: 300,
    remaining: 800,
    total: 2000,
    image: "/pikachu-pokemon-card-electric-cute.jpg",
    badge: "初心者",
    badgeColor: "green" as const,
  },
  {
    id: "4",
    title: "ワンピBOX",
    subtitle: "パラレル確定",
    price: 800,
    remaining: 200,
    total: 500,
    image: "/one-piece-card-luffy-manga-anime.jpg",
    badge: "NEW",
    badgeColor: "blue" as const,
  },
  {
    id: "5",
    title: "10万円BOX",
    subtitle: "超高額カード確定",
    price: 5000,
    remaining: 10,
    total: 100,
    image: "/rare-holographic-pokemon-card-rainbow.jpg",
    badge: "残りわずか",
    badgeColor: "red" as const,
  },
  {
    id: "6",
    title: "遊戯王BOX",
    subtitle: "レリーフ確定",
    price: 600,
    remaining: 350,
    total: 1000,
    image: "/yugioh-dark-magician-card-foil.jpg",
    badge: null,
    badgeColor: "gold" as const,
  },
]

export function GachaGrid() {
  return (
    <div className="flex flex-col gap-5">
      {gachaList.map((gacha) => (
        <GachaCard key={gacha.id} {...gacha} />
      ))}
    </div>
  )
}
