import { Sparkles } from "lucide-react"

export function GachaHero() {
  return (
    <section className="relative py-8">
      {/* Background glow effect */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="h-64 w-64 rounded-full bg-gold/20 blur-3xl" />
      </div>

      {/* Title */}
      <div className="relative mb-6 text-center">
        <div className="mb-2 flex items-center justify-center gap-2">
          <Sparkles className="h-5 w-5 text-gold" />
          <span className="text-sm font-medium tracking-wider text-gold">PREMIUM ORIPA</span>
          <Sparkles className="h-5 w-5 text-gold" />
        </div>
        <h1 className="bg-gradient-to-r from-gold-light via-gold to-amber bg-clip-text text-2xl font-black tracking-tight text-transparent md:text-3xl">
          超高級ポケカオリパ
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">激レア確定！夢のSARを手に入れろ！</p>
      </div>

      {/* Floating cards visual */}
      <div className="relative mx-auto h-56 w-full max-w-sm md:h-72">
        {/* Center main card */}
        <div className="absolute left-1/2 top-1/2 z-20 -translate-x-1/2 -translate-y-1/2">
          <div className="animate-pulse-glow relative h-40 w-28 overflow-hidden rounded-xl border-2 border-gold bg-gradient-to-br from-gold/30 via-card to-gold/20 shadow-2xl md:h-48 md:w-32">
            <img src="/pokemon-rare-trading-card-sar-shiny.jpg" alt="メインカード" className="h-full w-full object-cover" />
            <div className="animate-shimmer absolute inset-0" />
          </div>
        </div>

        {/* Left floating card */}
        <div className="animate-float absolute left-4 top-8 z-10 md:left-8">
          <div className="h-32 w-22 -rotate-12 overflow-hidden rounded-lg border border-gold/50 bg-gradient-to-br from-gold/20 to-card shadow-xl md:h-36 md:w-24">
            <img src="/pokemon-holographic-trading-card.jpg" alt="カード1" className="h-full w-full object-cover opacity-90" />
          </div>
        </div>

        {/* Right floating card */}
        <div className="animate-float-delayed absolute right-4 top-8 z-10 md:right-8">
          <div className="h-32 w-22 rotate-12 overflow-hidden rounded-lg border border-gold/50 bg-gradient-to-br from-gold/20 to-card shadow-xl md:h-36 md:w-24">
            <img src="/pokemon-special-art-rare-card.jpg" alt="カード2" className="h-full w-full object-cover opacity-90" />
          </div>
        </div>

        {/* Bottom left small card */}
        <div className="animate-float-delayed absolute bottom-4 left-12 z-5 md:left-16">
          <div className="h-24 w-16 -rotate-6 overflow-hidden rounded-md border border-gold/30 bg-card/50 shadow-lg opacity-70 md:h-28 md:w-18">
            <img src="/pokemon-v-card.jpg" alt="カード3" className="h-full w-full object-cover" />
          </div>
        </div>

        {/* Bottom right small card */}
        <div className="animate-float absolute bottom-4 right-12 z-5 md:right-16">
          <div className="h-24 w-16 rotate-6 overflow-hidden rounded-md border border-gold/30 bg-card/50 shadow-lg opacity-70 md:h-28 md:w-18">
            <img src="/pokemon-vmax-card.jpg" alt="カード4" className="h-full w-full object-cover" />
          </div>
        </div>

        {/* Sparkle particles */}
        <div className="absolute left-1/4 top-1/4 h-2 w-2 animate-pulse rounded-full bg-gold" />
        <div className="absolute right-1/3 top-1/3 h-1.5 w-1.5 animate-pulse rounded-full bg-gold-light delay-300" />
        <div className="absolute bottom-1/3 left-1/3 h-1 w-1 animate-pulse rounded-full bg-amber delay-500" />
        <div className="absolute bottom-1/4 right-1/4 h-2 w-2 animate-pulse rounded-full bg-gold delay-700" />
      </div>
    </section>
  )
}
