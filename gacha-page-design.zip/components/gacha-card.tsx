import Image from "next/image"
import Link from "next/link"
import { Sparkles } from "lucide-react"

interface GachaCardProps {
  id: string
  title: string
  subtitle: string
  price: number
  remaining: number
  total: number
  image: string
  badge: string | null
  badgeColor: "red" | "gold" | "green" | "blue"
}

const badgeColors = {
  red: "bg-gradient-to-r from-red-600 to-red-500 text-white",
  gold: "bg-gradient-to-r from-gold-light to-gold text-primary-foreground",
  green: "bg-gradient-to-r from-emerald-600 to-emerald-500 text-white",
  blue: "bg-gradient-to-r from-blue-600 to-blue-500 text-white",
}

export function GachaCard({ id, title, subtitle, price, remaining, total, image, badge, badgeColor }: GachaCardProps) {
  const progress = ((total - remaining) / total) * 100

  return (
    <div className="group relative overflow-hidden rounded-2xl border border-border/50 bg-gradient-to-b from-secondary/80 to-secondary/40 transition-all duration-300 hover:border-gold/50 hover:shadow-xl hover:shadow-gold/20">
      {/* Badge - 左上に大きめに配置 */}
      {badge && (
        <div
          className={`absolute left-3 top-3 z-10 flex items-center gap-1 rounded-lg px-3 py-1.5 text-sm font-bold shadow-lg ${badgeColors[badgeColor]}`}
        >
          <Sparkles className="h-3.5 w-3.5" />
          {badge}
        </div>
      )}

      {/* 残り口数 - 右上に配置 */}
      <div className="absolute right-3 top-3 z-10 rounded-lg bg-black/70 px-3 py-1.5 backdrop-blur-sm">
        <p className="text-xs font-medium text-white">
          残り <span className="text-gold">{remaining}</span>/{total}
        </p>
      </div>

      <Link href={`/gacha/${id}`}>
        <div className="relative aspect-video w-full overflow-hidden">
          <Image
            src={image || "/placeholder.svg"}
            alt={title}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-110"
          />
          {/* グラデーションオーバーレイ */}
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent" />
        </div>
      </Link>

      {/* Content - 下部に情報を配置 */}
      <div className="relative -mt-8 p-4 pt-0">
        <Link href={`/gacha/${id}`}>
          <h3 className="text-lg font-bold text-foreground">{title}</h3>
          <p className="mt-0.5 text-sm text-muted-foreground">{subtitle}</p>
        </Link>

        {/* Progress bar */}
        <div className="mt-3">
          <div className="h-2 overflow-hidden rounded-full bg-muted/50">
            <div
              className="h-full rounded-full bg-gradient-to-r from-gold-light via-gold to-amber transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        <div className="mt-4 flex gap-2">
          <button className="flex-1 rounded-lg bg-gradient-to-r from-secondary to-card border border-gold/30 px-2 py-2.5 text-center transition-all hover:border-gold hover:shadow-md hover:shadow-gold/20">
            <p className="text-xs text-muted-foreground">1回</p>
            <p className="bg-gradient-to-r from-gold-light to-gold bg-clip-text text-sm font-bold text-transparent">
              {price.toLocaleString()}pt
            </p>
          </button>
          <button className="flex-1 rounded-lg bg-gradient-to-r from-gold-dark/80 to-gold/80 border border-gold px-2 py-2.5 text-center transition-all hover:from-gold-dark hover:to-gold hover:shadow-md hover:shadow-gold/20">
            <p className="text-xs text-primary-foreground/80">10回</p>
            <p className="text-sm font-bold text-primary-foreground">{(price * 10).toLocaleString()}pt</p>
          </button>
          <button className="flex-1 rounded-lg bg-gradient-to-r from-amber/80 to-gold-light/80 border border-amber px-2 py-2.5 text-center transition-all hover:from-amber hover:to-gold-light hover:shadow-md hover:shadow-amber/20">
            <p className="text-xs text-primary-foreground/80">100回</p>
            <p className="text-sm font-bold text-primary-foreground">{(price * 100).toLocaleString()}pt</p>
          </button>
        </div>

        {/* 詳細リンク */}
        <Link
          href={`/gacha/${id}`}
          className="mt-3 block text-center text-xs text-muted-foreground underline-offset-2 hover:text-gold hover:underline"
        >
          詳細を見る →
        </Link>
      </div>
    </div>
  )
}
