"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import { Header } from "@/components/header"
import { GachaHero } from "@/components/gacha-hero"
import { GachaButtons } from "@/components/gacha-buttons"
import { RemainingProgress } from "@/components/remaining-progress"
import { PrizeCards } from "@/components/prize-cards"

interface GachaDetailPageProps {
  gachaId: string
}

export function GachaDetailPage({ gachaId }: GachaDetailPageProps) {
  const [points, setPoints] = useState(12500)
  const [remaining, setRemaining] = useState(120)
  const total = 1000

  const handlePull = (cost: number, pulls: number) => {
    if (points >= cost && remaining >= pulls) {
      setPoints((prev) => prev - cost)
      setRemaining((prev) => prev - pulls)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Header points={points} />

      <main className="container mx-auto px-4 pb-8">
        <Link
          href="/"
          className="mt-4 inline-flex items-center gap-2 rounded-full border border-border/50 bg-secondary/50 px-4 py-2 text-sm text-muted-foreground transition-colors hover:border-gold/30 hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" />
          一覧に戻る
        </Link>

        <GachaHero />

        <RemainingProgress remaining={remaining} total={total} />

        <GachaButtons points={points} remaining={remaining} onPull={handlePull} />

        <PrizeCards />
      </main>
    </div>
  )
}
