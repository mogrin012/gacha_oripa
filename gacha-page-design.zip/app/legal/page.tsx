import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function LegalPage() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header points={12500} />

      <main className="container mx-auto px-4 py-8 flex-1">
        <Link href="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-gold mb-6">
          <ArrowLeft className="h-4 w-4" />
          トップに戻る
        </Link>

        <div className="max-w-2xl mx-auto">
          <h1 className="text-2xl font-bold text-foreground mb-6">特定商取引法に基づく表記</h1>

          <div className="space-y-4">
            <div className="border-b border-border pb-4">
              <p className="text-sm text-muted-foreground mb-1">販売業者</p>
              <p className="text-foreground">株式会社プラスオリパ</p>
            </div>

            <div className="border-b border-border pb-4">
              <p className="text-sm text-muted-foreground mb-1">代表者</p>
              <p className="text-foreground">山田 太郎</p>
            </div>

            <div className="border-b border-border pb-4">
              <p className="text-sm text-muted-foreground mb-1">所在地</p>
              <p className="text-foreground">〒100-0001 東京都千代田区千代田1-1-1</p>
            </div>

            <div className="border-b border-border pb-4">
              <p className="text-sm text-muted-foreground mb-1">電話番号</p>
              <p className="text-foreground">03-1234-5678</p>
            </div>

            <div className="border-b border-border pb-4">
              <p className="text-sm text-muted-foreground mb-1">メールアドレス</p>
              <p className="text-foreground">info@plus-oripa.example.com</p>
            </div>

            <div className="border-b border-border pb-4">
              <p className="text-sm text-muted-foreground mb-1">販売価格</p>
              <p className="text-foreground">各商品ページに記載の価格（税込）</p>
            </div>

            <div className="border-b border-border pb-4">
              <p className="text-sm text-muted-foreground mb-1">支払方法</p>
              <p className="text-foreground">クレジットカード、銀行振込、コンビニ決済</p>
            </div>

            <div className="border-b border-border pb-4">
              <p className="text-sm text-muted-foreground mb-1">商品の引渡時期</p>
              <p className="text-foreground">
                ポイント購入：決済完了後即時
                <br />
                カード発送：ご注文から7営業日以内
              </p>
            </div>

            <div className="border-b border-border pb-4">
              <p className="text-sm text-muted-foreground mb-1">返品・交換について</p>
              <p className="text-foreground">デジタルコンテンツの性質上、購入後の返品・返金はお受けできません。</p>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
