import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header points={12500} />

      <main className="container mx-auto px-4 py-8 flex-1">
        <Link href="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-gold mb-6">
          <ArrowLeft className="h-4 w-4" />
          トップに戻る
        </Link>

        <div className="max-w-2xl mx-auto">
          <h1 className="text-2xl font-bold text-foreground mb-6">プライバシーポリシー</h1>

          <div className="space-y-6 text-muted-foreground">
            <section>
              <h2 className="text-lg font-bold text-foreground mb-2">個人情報の収集</h2>
              <p>
                当社は、サービス提供に必要な範囲で個人情報を収集します。
                収集する情報には、氏名、メールアドレス、住所、決済情報などが含まれます。
              </p>
            </section>

            <section>
              <h2 className="text-lg font-bold text-foreground mb-2">個人情報の利用目的</h2>
              <ul className="list-disc list-inside space-y-1">
                <li>サービスの提供・運営</li>
                <li>ユーザーからのお問い合わせ対応</li>
                <li>商品の発送</li>
                <li>サービス改善のための分析</li>
              </ul>
            </section>

            <section>
              <h2 className="text-lg font-bold text-foreground mb-2">個人情報の第三者提供</h2>
              <p>当社は、法令に基づく場合を除き、ユーザーの同意なく個人情報を第三者に提供しません。</p>
            </section>

            <section>
              <h2 className="text-lg font-bold text-foreground mb-2">お問い合わせ</h2>
              <p>
                個人情報に関するお問い合わせは、下記までご連絡ください。
                <br />
                メール: privacy@plus-oripa.example.com
              </p>
            </section>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
