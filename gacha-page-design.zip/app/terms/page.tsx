import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header points={12500} />

      <main className="container mx-auto px-4 py-8 flex-1">
        <Link href="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-gold mb-6">
          <ArrowLeft className="h-4 w-4" />
          トップに戻る
        </Link>

        <div className="max-w-2xl mx-auto">
          <h1 className="text-2xl font-bold text-foreground mb-6">利用規約</h1>

          <div className="space-y-6 text-muted-foreground">
            <section>
              <h2 className="text-lg font-bold text-foreground mb-2">第1条（適用）</h2>
              <p>
                本規約は、本サービスの利用に関する条件を定めるものです。
                ユーザーは本規約に同意の上、本サービスをご利用ください。
              </p>
            </section>

            <section>
              <h2 className="text-lg font-bold text-foreground mb-2">第2条（禁止事項）</h2>
              <ul className="list-disc list-inside space-y-1">
                <li>法令または公序良俗に違反する行為</li>
                <li>不正アクセス、システムへの攻撃行為</li>
                <li>他のユーザーへの迷惑行為</li>
                <li>虚偽情報の登録</li>
              </ul>
            </section>

            <section>
              <h2 className="text-lg font-bold text-foreground mb-2">第3条（ポイントについて）</h2>
              <p>ポイントは本サービス内でのみ使用可能です。 購入後のポイントは原則として返金できません。</p>
            </section>

            <section>
              <h2 className="text-lg font-bold text-foreground mb-2">第4条（免責事項）</h2>
              <p>
                当社は、本サービスの内容の正確性、完全性、有用性等について保証しません。
                ユーザーが本サービスを利用することにより生じた損害について、当社は責任を負いません。
              </p>
            </section>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
