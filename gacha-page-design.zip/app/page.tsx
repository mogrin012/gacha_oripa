import { Header } from "@/components/header"
import { GachaGrid } from "@/components/gacha-grid"
import { HeroBanner } from "@/components/hero-banner"
import { Footer } from "@/components/footer"

export default function Page() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header points={12500} />

      <main className="container mx-auto px-4 pb-8 flex-1">
        <HeroBanner />

        <section className="mt-8">
          <div className="mb-6 flex items-center gap-3">
            <div className="h-6 w-1 rounded-full bg-gradient-to-b from-gold-light to-gold" />
            <h2 className="text-xl font-bold text-foreground">開催中のオリパ</h2>
          </div>
          <GachaGrid />
        </section>
      </main>

      <Footer />
    </div>
  )
}
