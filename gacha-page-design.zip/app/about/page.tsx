import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header points={12500} />

      <main className="container mx-auto px-4 py-8 flex-1">
        <Link href="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-gold mb-6">
          <ArrowLeft className="h-4 w-4" />
          トップに戻る
        </Link>

        <div className="max-w-2xl mx-auto">
          <h1 className="text-2xl font-bold text-foreground mb-6">プラスオリパについて</h1>

          <div className="space-y-6 text-muted-foreground">
            <section>
              <h2 className="text-lg font-bold text-foreground mb-2">サービス概要</h2>
              <p>
                プラスオリパは、ポケモンカードをはじめとするトレーディングカードのオンラインオリパサービスです。
                厳選された高品質なカードを、公平な抽選システムでお届けします。
              </p>
            </section>

            <section>
              <h2 className="text-lg font-bold text-foreground mb-2">特徴</h2>
              <ul className="list-disc list-inside space-y-2">
                <li>厳選された高品質カードのラインナップ</li>
                <li>透明性の高い抽選システム</li>
                <li>安心・安全な取引環境</li>
                <li>迅速な発送対応</li>
              </ul>
            </section>

            <section>
              <h2 className="text-lg font-bold text-foreground mb-2">運営会社</h2>
              <p>
                株式会社プラスオリパ
                <br />
                〒100-0001 東京都千代田区千代田1-1-1
                <br />
                お問い合わせ: support@plus-oripa.example.com
              </p>
            </section>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
