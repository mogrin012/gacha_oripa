import { GachaDetailPage } from "@/components/gacha-detail-page"

export default async function GachaPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const resolvedParams = await params
  return <GachaDetailPage gachaId={resolvedParams.id} />
}
