"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { ArrowLeft, Upload, Plus, Package, CreditCard, Trash2, ExternalLink } from "lucide-react"

// ダミーデータ: 登録済みカード
const mockCards = [
  { id: "1", name: "リザードン SAR", points: 50000, image: "/charizard-pokemon-card-holographic-fire.jpg" },
  { id: "2", name: "ピカチュウ AR", points: 8000, image: "/pikachu-pokemon-card-electric-cute.jpg" },
  { id: "3", name: "ミュウ UR", points: 30000, image: "/pokemon-rare-trading-card-sar-shiny.jpg" },
  { id: "4", name: "ルフィ SEC", points: 25000, image: "/one-piece-card-luffy-manga-anime.jpg" },
  { id: "5", name: "ゲッコウガ SAR", points: 15000, image: "/rare-holographic-pokemon-card-rainbow.jpg" },
  { id: "6", name: "リーリエ SR", points: 45000, image: "/yugioh-rare-trading-card-holographic.jpg" },
]

// ダミーデータ: 開催中ガチャ
const mockGachas = [
  { id: "1", title: "リザードン確定オリパ", remaining: 120, total: 1000, price: 500, status: "active" },
  { id: "2", title: "激アツ！高額カードオリパ", remaining: 450, total: 500, price: 1000, status: "active" },
  { id: "3", title: "ワンピースコラボオリパ", remaining: 280, total: 800, price: 300, status: "active" },
]

export default function AdminPage() {
  const [activeTab, setActiveTab] = useState<"cards" | "gachas">("cards")
  const [cardName, setCardName] = useState("")
  const [cardPoints, setCardPoints] = useState("")
  const [dragActive, setDragActive] = useState(false)

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)
    // ファイル処理ロジック（実際の実装では画像アップロード処理を行う）
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border/50 bg-background/80 backdrop-blur-xl">
        <div className="container mx-auto flex h-14 items-center justify-between px-4">
          <div className="flex items-center gap-4">
            <Link href="/" className="text-muted-foreground hover:text-gold">
              <ArrowLeft className="h-5 w-5" />
            </Link>
            <h1 className="text-lg font-bold text-foreground">管理画面</h1>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        {/* Tabs */}
        <div className="flex gap-2 mb-6">
          <button
            onClick={() => setActiveTab("cards")}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all ${
              activeTab === "cards"
                ? "bg-gradient-to-r from-gold-dark to-gold text-primary-foreground"
                : "bg-secondary text-muted-foreground hover:text-foreground"
            }`}
          >
            <CreditCard className="h-4 w-4" />
            カード管理
          </button>
          <button
            onClick={() => setActiveTab("gachas")}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all ${
              activeTab === "gachas"
                ? "bg-gradient-to-r from-gold-dark to-gold text-primary-foreground"
                : "bg-secondary text-muted-foreground hover:text-foreground"
            }`}
          >
            <Package className="h-4 w-4" />
            ガチャ管理
          </button>
        </div>

        {/* カード管理タブ */}
        {activeTab === "cards" && (
          <div className="space-y-8">
            {/* カード登録フォーム */}
            <section className="rounded-xl border border-border/50 bg-secondary/30 p-6">
              <h2 className="text-lg font-bold text-foreground mb-4">カード登録</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-muted-foreground mb-2">カード名</label>
                  <input
                    type="text"
                    value={cardName}
                    onChange={(e) => setCardName(e.target.value)}
                    placeholder="例: リザードン SAR"
                    className="w-full rounded-lg border border-border bg-background px-4 py-3 text-foreground placeholder:text-muted-foreground focus:border-gold focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-sm text-muted-foreground mb-2">ポイント（変換時のポイント数）</label>
                  <input
                    type="number"
                    value={cardPoints}
                    onChange={(e) => setCardPoints(e.target.value)}
                    placeholder="例: 50000"
                    className="w-full rounded-lg border border-border bg-background px-4 py-3 text-foreground placeholder:text-muted-foreground focus:border-gold focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-sm text-muted-foreground mb-2">画像アップロード</label>
                  <div
                    onDragEnter={handleDrag}
                    onDragLeave={handleDrag}
                    onDragOver={handleDrag}
                    onDrop={handleDrop}
                    className={`flex flex-col items-center justify-center rounded-xl border-2 border-dashed p-8 transition-all ${
                      dragActive ? "border-gold bg-gold/10" : "border-border hover:border-gold/50 hover:bg-secondary/50"
                    }`}
                  >
                    <Upload className="h-10 w-10 text-muted-foreground mb-3" />
                    <p className="text-sm text-muted-foreground text-center">
                      ドラッグ＆ドロップ、または
                      <button className="text-gold hover:underline ml-1">ファイルを選択</button>
                    </p>
                    <p className="text-xs text-muted-foreground mt-2">PNG, JPG, WEBP（最大5MB）</p>
                  </div>
                </div>

                <button className="w-full rounded-lg bg-gradient-to-r from-gold-dark to-gold py-3 font-bold text-primary-foreground transition-all hover:shadow-lg hover:shadow-gold/30">
                  <Plus className="inline-block h-4 w-4 mr-2" />
                  カードを登録
                </button>
              </div>
            </section>

            {/* 登録済みカード一覧 */}
            <section>
              <h2 className="text-lg font-bold text-foreground mb-4">登録済みカード一覧</h2>
              <div className="grid grid-cols-3 gap-3">
                {mockCards.map((card) => (
                  <div
                    key={card.id}
                    className="group relative overflow-hidden rounded-xl border border-border/50 bg-secondary/30"
                  >
                    <div className="relative aspect-[3/4]">
                      <Image src={card.image || "/placeholder.svg"} alt={card.name} fill className="object-cover" />
                    </div>
                    <div className="p-2">
                      <p className="text-xs font-medium text-foreground truncate">{card.name}</p>
                      <p className="text-xs text-gold">{card.points.toLocaleString()}pt</p>
                    </div>
                    <button className="absolute top-2 right-2 p-1.5 rounded-lg bg-red-500/80 text-white opacity-0 group-hover:opacity-100 transition-opacity">
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>
                ))}
              </div>
            </section>
          </div>
        )}

        {/* ガチャ管理タブ */}
        {activeTab === "gachas" && (
          <div className="space-y-8">
            {/* ガチャ追加リンク */}
            <Link
              href="/admin/gacha/new"
              className="flex items-center justify-center gap-2 rounded-xl border-2 border-dashed border-gold/50 bg-gold/5 py-6 text-gold hover:bg-gold/10 transition-all"
            >
              <Plus className="h-5 w-5" />
              <span className="font-bold">新しいガチャを追加</span>
            </Link>

            {/* 開催中ガチャ一覧 */}
            <section>
              <h2 className="text-lg font-bold text-foreground mb-4">開催中のガチャ一覧</h2>
              <div className="space-y-3">
                {mockGachas.map((gacha) => {
                  const progress = ((gacha.total - gacha.remaining) / gacha.total) * 100
                  return (
                    <div key={gacha.id} className="rounded-xl border border-border/50 bg-secondary/30 p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="font-bold text-foreground">{gacha.title}</h3>
                        <span className="px-2 py-0.5 rounded-full bg-green-500/20 text-green-500 text-xs font-medium">
                          開催中
                        </span>
                      </div>

                      <div className="flex items-center gap-4 text-sm text-muted-foreground mb-3">
                        <span>価格: {gacha.price}pt</span>
                        <span>
                          残り: {gacha.remaining}/{gacha.total}
                        </span>
                      </div>

                      <div className="h-2 overflow-hidden rounded-full bg-muted/50 mb-3">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-gold-light via-gold to-amber"
                          style={{ width: `${progress}%` }}
                        />
                      </div>

                      <Link
                        href={`/admin/gacha/${gacha.id}`}
                        className="inline-flex items-center gap-1 text-sm text-gold hover:underline"
                      >
                        詳細を見る
                        <ExternalLink className="h-3 w-3" />
                      </Link>
                    </div>
                  )
                })}
              </div>
            </section>
          </div>
        )}
      </main>
    </div>
  )
}
