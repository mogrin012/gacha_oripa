"use client"

import { useParams } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { ArrowLeft, Edit } from "lucide-react"

// ダミーデータ: ガチャ詳細
const mockGachaDetail = {
  id: "1",
  title: "リザードン確定オリパ",
  subtitle: "SARが必ず当たる！",
  price: 500,
  total: 1000,
  remaining: 120,
  cards: [
    {
      id: "1",
      name: "リザードン SAR",
      points: 50000,
      image: "/charizard-pokemon-card-holographic-fire.jpg",
      sold: true,
    },
    { id: "2", name: "ピカチュウ AR", points: 8000, image: "/pikachu-pokemon-card-electric-cute.jpg", sold: false },
    { id: "3", name: "ミュウ UR", points: 30000, image: "/pokemon-rare-trading-card-sar-shiny.jpg", sold: true },
    { id: "4", name: "ルフィ SEC", points: 25000, image: "/one-piece-card-luffy-manga-anime.jpg", sold: false },
    { id: "5", name: "ゲッコウガ SAR", points: 15000, image: "/rare-holographic-pokemon-card-rainbow.jpg", sold: true },
    { id: "6", name: "リーリエ SR", points: 45000, image: "/yugioh-rare-trading-card-holographic.jpg", sold: false },
    {
      id: "7",
      name: "リザードン SAR",
      points: 50000,
      image: "/charizard-pokemon-card-holographic-fire.jpg",
      sold: true,
    },
    { id: "8", name: "ピカチュウ AR", points: 8000, image: "/pikachu-pokemon-card-electric-cute.jpg", sold: true },
    { id: "9", name: "ミュウ UR", points: 30000, image: "/pokemon-rare-trading-card-sar-shiny.jpg", sold: false },
  ],
}

export default function GachaDetailPage() {
  const params = useParams()
  const id = params.id as string
  const gacha = mockGachaDetail
  const progress = ((gacha.total - gacha.remaining) / gacha.total) * 100

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border/50 bg-background/80 backdrop-blur-xl">
        <div className="container mx-auto flex h-14 items-center justify-between px-4">
          <div className="flex items-center gap-4">
            <Link href="/admin" className="text-muted-foreground hover:text-gold">
              <ArrowLeft className="h-5 w-5" />
            </Link>
            <h1 className="text-lg font-bold text-foreground">ガチャ詳細</h1>
          </div>
          <button className="flex items-center gap-2 rounded-lg bg-secondary px-3 py-2 text-sm text-muted-foreground hover:text-foreground">
            <Edit className="h-4 w-4" />
            編集
          </button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <div className="space-y-6">
          {/* 基本情報 */}
          <section className="rounded-xl border border-border/50 bg-secondary/30 p-6">
            <h2 className="text-xl font-bold text-foreground">{gacha.title}</h2>
            <p className="text-muted-foreground">{gacha.subtitle}</p>

            <div className="mt-4 grid grid-cols-2 gap-4">
              <div className="rounded-lg bg-background/50 p-4">
                <p className="text-sm text-muted-foreground">総口数</p>
                <p className="text-2xl font-bold text-foreground">{gacha.total.toLocaleString()}</p>
              </div>
              <div className="rounded-lg bg-background/50 p-4">
                <p className="text-sm text-muted-foreground">残口数</p>
                <p className="text-2xl font-bold text-gold">{gacha.remaining.toLocaleString()}</p>
              </div>
            </div>

            {/* プログレスバー */}
            <div className="mt-4">
              <div className="flex justify-between text-sm mb-2">
                <span className="text-muted-foreground">販売進捗</span>
                <span className="text-gold">{progress.toFixed(1)}%</span>
              </div>
              <div className="h-3 overflow-hidden rounded-full bg-muted/50">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-gold-light via-gold to-amber"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          </section>

          {/* 使用カード一覧 */}
          <section>
            <h2 className="text-lg font-bold text-foreground mb-4">使用カード一覧</h2>
            <div className="grid grid-cols-3 gap-3">
              {gacha.cards.map((card, index) => (
                <div
                  key={`${card.id}-${index}`}
                  className={`relative overflow-hidden rounded-xl border ${
                    card.sold ? "border-red-500/50" : "border-border/50"
                  } bg-secondary/30`}
                >
                  <div className="relative aspect-[3/4]">
                    <Image
                      src={card.image || "/placeholder.svg"}
                      alt={card.name}
                      fill
                      className={`object-cover ${card.sold ? "opacity-50" : ""}`}
                    />
                    {card.sold && (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="rotate-[-15deg] rounded-lg bg-red-500 px-3 py-1 text-sm font-bold text-white shadow-lg">
                          排出済
                        </div>
                      </div>
                    )}
                  </div>
                  <div className="p-2">
                    <p className="text-xs font-medium text-foreground truncate">{card.name}</p>
                    <p className="text-xs text-gold">{card.points.toLocaleString()}pt</p>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>
      </main>
    </div>
  )
}
