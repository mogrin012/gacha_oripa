"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { ArrowLeft, Upload, Plus, Check } from "lucide-react"

// ダミーデータ: 登録済みカード（選択用）
const availableCards = [
  { id: "1", name: "リザードン SAR", points: 50000, image: "/charizard-pokemon-card-holographic-fire.jpg" },
  { id: "2", name: "ピカチュウ AR", points: 8000, image: "/pikachu-pokemon-card-electric-cute.jpg" },
  { id: "3", name: "ミュウ UR", points: 30000, image: "/pokemon-rare-trading-card-sar-shiny.jpg" },
  { id: "4", name: "ルフィ SEC", points: 25000, image: "/one-piece-card-luffy-manga-anime.jpg" },
  { id: "5", name: "ゲッコウガ SAR", points: 15000, image: "/rare-holographic-pokemon-card-rainbow.jpg" },
  { id: "6", name: "リーリエ SR", points: 45000, image: "/yugioh-rare-trading-card-holographic.jpg" },
]

export default function NewGachaPage() {
  const [title, setTitle] = useState("")
  const [subtitle, setSubtitle] = useState("")
  const [price, setPrice] = useState("")
  const [totalPulls, setTotalPulls] = useState("")
  const [selectedCards, setSelectedCards] = useState<string[]>([])
  const [dragActive, setDragActive] = useState(false)

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)
  }

  const toggleCard = (cardId: string) => {
    setSelectedCards((prev) => (prev.includes(cardId) ? prev.filter((id) => id !== cardId) : [...prev, cardId]))
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border/50 bg-background/80 backdrop-blur-xl">
        <div className="container mx-auto flex h-14 items-center justify-between px-4">
          <div className="flex items-center gap-4">
            <Link href="/admin" className="text-muted-foreground hover:text-gold">
              <ArrowLeft className="h-5 w-5" />
            </Link>
            <h1 className="text-lg font-bold text-foreground">新規ガチャ作成</h1>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <div className="space-y-6">
          {/* 基本情報 */}
          <section className="rounded-xl border border-border/50 bg-secondary/30 p-6">
            <h2 className="text-lg font-bold text-foreground mb-4">基本情報</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-muted-foreground mb-2">ガチャタイトル</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="例: リザードン確定オリパ"
                  className="w-full rounded-lg border border-border bg-background px-4 py-3 text-foreground placeholder:text-muted-foreground focus:border-gold focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-sm text-muted-foreground mb-2">サブタイトル</label>
                <input
                  type="text"
                  value={subtitle}
                  onChange={(e) => setSubtitle(e.target.value)}
                  placeholder="例: SARが必ず当たる！"
                  className="w-full rounded-lg border border-border bg-background px-4 py-3 text-foreground placeholder:text-muted-foreground focus:border-gold focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-muted-foreground mb-2">1回の価格（pt）</label>
                  <input
                    type="number"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    placeholder="500"
                    className="w-full rounded-lg border border-border bg-background px-4 py-3 text-foreground placeholder:text-muted-foreground focus:border-gold focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-sm text-muted-foreground mb-2">総口数</label>
                  <input
                    type="number"
                    value={totalPulls}
                    onChange={(e) => setTotalPulls(e.target.value)}
                    placeholder="1000"
                    className="w-full rounded-lg border border-border bg-background px-4 py-3 text-foreground placeholder:text-muted-foreground focus:border-gold focus:outline-none"
                  />
                </div>
              </div>
            </div>
          </section>

          {/* サムネイル画像 */}
          <section className="rounded-xl border border-border/50 bg-secondary/30 p-6">
            <h2 className="text-lg font-bold text-foreground mb-4">サムネイル画像</h2>
            <div
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
              className={`flex flex-col items-center justify-center rounded-xl border-2 border-dashed p-8 transition-all ${
                dragActive ? "border-gold bg-gold/10" : "border-border hover:border-gold/50 hover:bg-secondary/50"
              }`}
            >
              <Upload className="h-10 w-10 text-muted-foreground mb-3" />
              <p className="text-sm text-muted-foreground text-center">
                ドラッグ＆ドロップ、または
                <button className="text-gold hover:underline ml-1">ファイルを選択</button>
              </p>
              <p className="text-xs text-muted-foreground mt-2">推奨サイズ: 16:9（1920×1080）</p>
            </div>
          </section>

          {/* カード選択 */}
          <section className="rounded-xl border border-border/50 bg-secondary/30 p-6">
            <h2 className="text-lg font-bold text-foreground mb-4">
              使用するカードを選択
              <span className="ml-2 text-sm font-normal text-muted-foreground">（{selectedCards.length}枚選択中）</span>
            </h2>
            <div className="grid grid-cols-3 gap-3">
              {availableCards.map((card) => {
                const isSelected = selectedCards.includes(card.id)
                return (
                  <button
                    key={card.id}
                    onClick={() => toggleCard(card.id)}
                    className={`relative overflow-hidden rounded-xl border-2 transition-all ${
                      isSelected ? "border-gold shadow-lg shadow-gold/20" : "border-border/50 hover:border-gold/50"
                    }`}
                  >
                    <div className="relative aspect-[3/4]">
                      <Image src={card.image || "/placeholder.svg"} alt={card.name} fill className="object-cover" />
                      {isSelected && (
                        <div className="absolute inset-0 bg-gold/20 flex items-center justify-center">
                          <div className="h-8 w-8 rounded-full bg-gold flex items-center justify-center">
                            <Check className="h-5 w-5 text-primary-foreground" />
                          </div>
                        </div>
                      )}
                    </div>
                    <div className="p-2">
                      <p className="text-xs font-medium text-foreground truncate">{card.name}</p>
                      <p className="text-xs text-gold">{card.points.toLocaleString()}pt</p>
                    </div>
                  </button>
                )
              })}
            </div>
          </section>

          {/* 保存ボタン */}
          <button className="w-full rounded-xl bg-gradient-to-r from-gold-dark to-gold py-4 font-bold text-primary-foreground transition-all hover:shadow-lg hover:shadow-gold/30">
            <Plus className="inline-block h-5 w-5 mr-2" />
            ガチャを作成
          </button>
        </div>
      </main>
    </div>
  )
}
